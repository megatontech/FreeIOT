TemperatureMonitor
==================

Uses Open Hardware Monitor to constantly monitor the temperature of CPU, and carry out any action. 
(In this case close the FireFox)

Get temperature values, using the Exposed WMI.
